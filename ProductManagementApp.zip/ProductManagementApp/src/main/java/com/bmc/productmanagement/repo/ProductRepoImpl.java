package com.bmc.productmanagement.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.bmc.productmanagement.model.Product;

@Repository
@Transactional
public class ProductRepoImpl implements ProductRepo {
	@PersistenceContext
	EntityManager em; // persist(),merge(),remove(),find(),createQuery()

	@Override
	public String addProduct(Product product) {
		em.persist(product);
		return "Product Inserted Successfully";
	}

	@Override
	public String updateProduct(Product product) {
		em.merge(product);
		return "Product Updated Successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		em.remove(getProduct(productId));
		return "Product Removed Successfully ";
	}

	@Override
	public Product getProduct(int productId) {
		return em.find(Product.class, productId);
	}

	@Override
	public List<Product> getAllProducts() {
		TypedQuery<Product> products = em.createQuery("select p from Product p", Product.class);
		return products.getResultList();
	}

	@Override
	public List<Product> getAllProductsInBetween(int intialPrice, int finalPrice) {
		TypedQuery<Product> products = em.createQuery("select p from Product p where p.price between ?1 and ?2",
				Product.class);
		products.setParameter(1, intialPrice);
		products.setParameter(2, finalPrice);
		return products.getResultList();
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		TypedQuery<Product> products = em.createQuery("select p from Product p where p.productCategory=?1", Product.class);
		products.setParameter(1,category);
		return products.getResultList();
	}

}
