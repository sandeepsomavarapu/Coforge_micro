package com.bmc.productmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bmc.productmanagement.model.Product;
import com.bmc.productmanagement.service.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {
	@Autowired
	ProductService service;

	@RequestMapping("/getMessage") // http://localhost:4545/products/getMessage
	public String sayHello() {
		return "Hello Everyone !!!!!";
	}

	@PostMapping("/insertProduct") // http://localhost:4545/products/insertProduct
	public String insertProduct(@RequestBody Product product) {
		return service.addProduct(product);
	}

	@PutMapping("/update") // http://localhost:4545/products/update
	public String updateProduct(@RequestBody Product product) {
		return service.updateProduct(product);
	}

	@DeleteMapping("/delete/{pid}") // http://localhost:4545/products/delete
	public String deleteProduct(@PathVariable("pid") int productId) {
		return service.deleteProduct(productId);
	}

	@GetMapping("/get/{pid}") // http://localhost:4545/products/get
	public Product getProduct(@PathVariable("pid") int productId) {
		return service.getProduct(productId);
	}

	@GetMapping("/getAll") // http://localhost:4545/products/getAll
	public List<Product> getAll() {
		return service.getAllProducts();
	}

	@GetMapping("/getAllInBetween/{p1}/{p2}") // http://localhost:4545/products/getAllInBetween/12000/15000
	public List<Product> getAllBetween(@PathVariable("p1") int price1, @PathVariable("p2") int price2) {
		return service.getAllProductsInBetween(price1, price2);
	}

	@GetMapping("/getAllByCategory/{c1}") // http://localhost:4545/products/getAllInBetween/12000/15000
	public List<Product> getAllByCategory(@PathVariable("c1") String category) {
		return service.getAllProductsByCategory(category);
	}
}
