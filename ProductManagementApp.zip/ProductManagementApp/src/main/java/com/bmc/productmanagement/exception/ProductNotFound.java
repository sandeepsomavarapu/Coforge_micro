package com.bmc.productmanagement.exception;

public class ProductNotFound extends RuntimeException {
	ProductNotFound(String message)
	{
		super(message);
	}
}
