package com.bmc.productmanagement.repo;

import java.util.List;

import com.bmc.productmanagement.model.Product;

public interface ProductRepo {
	public abstract String addProduct(Product product);

	public String updateProduct(Product product);

	public String deleteProduct(int productId);

	public Product getProduct(int productId);

	public List<Product> getAllProducts();

	public List<Product> getAllProductsInBetween(int intialPrice, int finalPrice);

	public List<Product> getAllProductsByCategory(String category);

}
