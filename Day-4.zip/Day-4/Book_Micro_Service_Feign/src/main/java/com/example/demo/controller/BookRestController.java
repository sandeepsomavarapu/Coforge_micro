package com.example.demo.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.bean.Book;

@RestController
@RequestMapping("/book")
public class BookRestController {

	@GetMapping("/{id}")
	public Book getBookById(@PathVariable Integer id) {
		return new Book(id, "Core Java", 345.45);
	}

	@GetMapping("/getAllBooks")
	public List<Book> getAllBooks() {
		Book b1 = new Book(111, "Core Java", 345.45);
		Book b2 = new Book(1223, "spring", 645.54);
		Book b3 = new Book(321, "microservices", 2345.85);
		ArrayList<Book> al = new ArrayList<Book>();
		al.add(b1);
		al.add(b2);
		al.add(b3);
		return al;
	}

}
