package com.example.demo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.demo.bean.Book;

@FeignClient(name = "book-service", url = "localhost:9922/book")
public interface BookConsumerFeign {

	@GetMapping("/{id}")
	public Book getBookById(@PathVariable Integer id);

	@GetMapping("/getAllBooks")
	public List<Book> getAllBooks();
}
