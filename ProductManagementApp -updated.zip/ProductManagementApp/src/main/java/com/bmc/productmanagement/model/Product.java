package com.bmc.productmanagement.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Size;

@Entity
@Table(name = "product_info")//select pname from products_info; mysql
public class Product {		 //select productName from Product p;  JPQL

	@Id
	private int productId;
	@Column(name = "pname", length = 20)
	@NotBlank(message="the productname can't be null or empty")
	private String productName;
	private String productCategory;
	@Min(value=1000,message="The Price must be greater than 1000")
	private int price;
	@Size(min=8,max=20,message="Description must be min 8 and max 20 chars only..")
	private String productDesc;
	public int getProductId() {
		return productId;
	}
	public void setProductId(int productId) {
		this.productId = productId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getProductCategory() {
		return productCategory;
	}
	public void setProductCategory(String productCategory) {
		this.productCategory = productCategory;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getProductDesc() {
		return productDesc;
	}
	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}
	public Product(int productId, String productName, String productCategory, int price, String productDesc) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.productCategory = productCategory;
		this.price = price;
		this.productDesc = productDesc;
	}
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productCategory="
				+ productCategory + ", price=" + price + ", productDesc=" + productDesc + "]";
	}
	
	public Product()
	{
		
	}
	

}
