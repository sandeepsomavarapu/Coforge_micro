package com.bmc.productmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bmc.productmanagement.exception.ProductNotFound;
import com.bmc.productmanagement.model.Product;
import com.bmc.productmanagement.repo.ProductRepo;

@Service
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductRepo repo;

	@Override
	public String addProduct(Product product) {
		repo.save(product);
		return "Product Inserted Succesfully";
	}

	@Override
	public String updateProduct(Product product) {
			repo.save(product);
		return "Product Updated successfully";
	}

	@Override
	public String deleteProduct(int productId) {
		repo.deleteById(productId);
		return "Product Deleted";
	}

	@Override
	public Product getProduct(int productId) {
		Optional<Product>optional=repo.findById(productId);
		if(optional.isPresent())
			return optional.get();
		else
			throw new ProductNotFound("ProductId is invalid");
	}

	@Override
	public List<Product> getAllProducts() {
		return repo.findAll();
	}

	@Override
	public List<Product> getAllProductsInBetween(int intialPrice, int finalPrice) {
		return repo.findBypriceBetween(intialPrice, finalPrice);
	}

	@Override
	public List<Product> getAllProductsByCategory(String category) {
		return repo.findByProductCategory(category);
	}

}
