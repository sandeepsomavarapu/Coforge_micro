package com.bmc.productmanagement;

import org.springframework.boot.actuate.endpoint.annotation.Endpoint;
import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;

@Endpoint(id="welcomemsg")
@Component
public class CustomEndPoint {
	@ReadOperation
	@Bean
	public String getMessage() {
		
		return "welcome to spring boot actuators";
	}
}
